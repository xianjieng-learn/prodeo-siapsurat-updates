from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

from common import (
    create_shortcuts, data_dir, ensure_requirements, install_payload, install_root,
    log, message_box, read_state, start_app, stop_parent, verify_program,
    wait_startup, write_state,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("update", "rollback"), default="update")
    parser.add_argument("--package", default="")
    parser.add_argument("--parent-pid", type=int, default=0)
    return parser.parse_args()


def main() -> int:
    args = parse_args(); root = install_root(); state = read_state(root)
    log(f"Updater start mode={args.mode} active={state['active']}", name="updater.log")
    stop_parent(args.parent_pid)
    try:
        if args.mode == "rollback":
            previous = state.get("previous", "")
            if not previous or not (root / "versions" / previous).is_dir():
                raise RuntimeError("Versi sebelumnya tidak tersedia")
            verify_program(root / "versions" / previous)
            old = state["active"]
            write_state({"active": previous, "previous": old, "last_good": previous}, root)
            create_shortcuts(root); start_app(root)
            message_box("Prodeo SIAPSurat", f"Rollback ke versi {previous} selesai.")
            return 0

        package = Path(args.package).resolve()
        if not package.is_file():
            raise FileNotFoundError("Paket update tidak ditemukan")
        old = state["active"]
        new, program_dir = install_payload(package, root)
        ensure_requirements(program_dir)
        write_state({"active": new, "previous": old if old != new else state.get("previous", ""), "last_good": old}, root)
        create_shortcuts(root)
        if wait_startup(new):
            write_state({"active": new, "previous": old if old != new else state.get("previous", ""), "last_good": new}, root)
            log(f"Update success {old} -> {new}", name="updater.log")
            message_box("Prodeo SIAPSurat", f"Pembaruan ke versi {new} berhasil.")
            return 0
        log(f"Startup failed version={new}; rollback={old}", name="updater.log")
        write_state({"active": old, "previous": new, "last_good": old}, root)
        start_app(root)
        raise RuntimeError(f"Versi {new} gagal dibuka. Aplikasi telah kembali ke versi {old}.")
    except Exception as exc:
        log(f"ERROR {type(exc).__name__}: {exc}", name="updater.log")
        message_box("Prodeo SIAPSurat - Pembaruan", str(exc), error=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
