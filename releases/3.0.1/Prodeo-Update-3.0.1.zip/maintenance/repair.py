from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path

from common import (
    create_shortcuts, data_dir, ensure_requirements, install_payload, install_root,
    log, message_box, read_state, start_app, stop_parent, verify_program, winget_install,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent-pid", type=int, default=0)
    parser.add_argument("--safe-mode", action="store_true")
    return parser.parse_args()


def webview_installed() -> bool:
    if os.name != "nt": return True
    try:
        import winreg
        keys = [
            r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F1E7E5A1-9D4B-4C58-8B39-65D79D0D7F5E}",
            r"SOFTWARE\Microsoft\EdgeUpdate\Clients\{F1E7E5A1-9D4B-4C58-8B39-65D79D0D7F5E}",
        ]
        return any(_key_exists(winreg.HKEY_LOCAL_MACHINE, key) or _key_exists(winreg.HKEY_CURRENT_USER, key) for key in keys)
    except Exception:
        return False


def _key_exists(hive, path: str) -> bool:
    import winreg
    try:
        with winreg.OpenKey(hive, path): return True
    except OSError: return False


def libreoffice_installed() -> bool:
    candidates = [
        Path(os.getenv("ProgramW6432", "")) / "LibreOffice/program/soffice.exe",
        Path(os.getenv("ProgramFiles", "")) / "LibreOffice/program/soffice.exe",
        Path(os.getenv("ProgramFiles(x86)", "")) / "LibreOffice/program/soffice.exe",
        Path(os.getenv("LOCALAPPDATA", "")) / "Programs/LibreOffice/program/soffice.exe",
    ]
    return bool(shutil.which("soffice.exe") or shutil.which("soffice") or any(p.is_file() for p in candidates))


def main() -> int:
    args = parse_args(); root = install_root(); data = data_dir(); stop_parent(args.parent_pid)
    log("Repair start", name="repair.log")
    try:
        state = read_state(root); active = state["active"]; program = root / "versions" / active
        try:
            verify_program(program)
        except Exception as first_error:
            recovery = root / "recovery" / f"Prodeo-Update-{active}.zip"
            if not recovery.is_file():
                raise RuntimeError(f"File program rusak dan paket recovery {active} tidak tersedia: {first_error}")
            _, program = install_payload(recovery, root)
            verify_program(program)
        ensure_requirements(program)
        create_shortcuts(root)
        if not webview_installed(): winget_install("Microsoft.EdgeWebView2Runtime")
        if not libreoffice_installed(): winget_install("TheDocumentFoundation.LibreOffice")
        shutil.rmtree(data / "tmp", ignore_errors=True); (data / "tmp").mkdir(parents=True, exist_ok=True)
        cache = data / "webview-data" / "EBWebView" / "Default" / "Cache"
        shutil.rmtree(cache, ignore_errors=True)
        start_app(root, safe_mode=args.safe_mode)
        log(f"Repair success active={active}", name="repair.log")
        message_box("Prodeo SIAPSurat", "Perbaikan instalasi selesai.")
        return 0
    except Exception as exc:
        log(f"ERROR {type(exc).__name__}: {exc}", name="repair.log")
        message_box("Prodeo SIAPSurat - Perbaikan", str(exc), error=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
