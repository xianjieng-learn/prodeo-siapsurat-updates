"""Standalone maintenance helpers used by the native updater and repair EXEs."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

VERSION_RE_CHARS = set("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-")
APP_ID = "PAJaktim.ProdeoSIAPSurat.Desktop"


def install_root() -> Path:
    value = os.getenv("PRODEO_INSTALL_ROOT", "").strip()
    return Path(value).resolve() if value else Path(__file__).resolve().parent.parent


def data_dir() -> Path:
    value = os.getenv("PRODEO_DATA_DIR", "").strip()
    if value:
        return Path(value).resolve()
    local = os.getenv("LOCALAPPDATA", "")
    return (Path(local) / "ProdeoSIAPSuratDesktop").resolve() if local else (install_root() / ".data").resolve()


def log(message: str, *, name: str = "maintenance.log") -> None:
    path = data_dir() / "logs" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    line = f"{datetime.now().isoformat(timespec='seconds')} {message}\n"
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(line)


def message_box(title: str, message: str, error: bool = False) -> None:
    if os.name != "nt":
        print(f"{title}: {message}", file=sys.stderr if error else sys.stdout)
        return
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, str(message), str(title), 0x10 if error else 0x40)
    except Exception:
        pass


def valid_version(value: object) -> bool:
    text = str(value or "").strip()
    return bool(text and all(ch in VERSION_RE_CHARS for ch in text) and text[0].isdigit() and "." in text)


def state_path(root: Path | None = None) -> Path:
    return (root or install_root()) / "state.json"


def read_state(root: Path | None = None) -> dict[str, Any]:
    path = state_path(root)
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(data, dict) or not valid_version(data.get("active")):
            raise ValueError("state.json rusak")
        return {
            "schema": int(data.get("schema", 1)),
            "active": str(data["active"]),
            "previous": str(data.get("previous", "")) if valid_version(data.get("previous")) else "",
            "last_good": str(data.get("last_good", "")) if valid_version(data.get("last_good")) else "",
            "updated_at": str(data.get("updated_at", "")),
        }
    except Exception:
        version_root = (root or install_root()).joinpath("versions")
        candidates = []
        for item in version_root.glob("*") if version_root.is_dir() else []:
            if not item.is_dir() or item.name.endswith(".staging") or not valid_version(item.name):
                continue
            if not (item / "desktop_app.py").is_file() or not (item / "app-manifest.json").is_file():
                continue
            parts = tuple(int("".join(ch for ch in part if ch.isdigit()) or 0) for part in item.name.split("."))
            candidates.append((parts, item.name))
        active = max(candidates, default=((3, 0, 1), "3.0.1"))[1]
        return {"schema": 1, "active": active, "previous": "", "last_good": active, "updated_at": ""}


def write_state(state: dict[str, Any], root: Path | None = None) -> None:
    root = root or install_root()
    active = str(state.get("active", "")).strip()
    if not valid_version(active):
        raise ValueError("Versi aktif tidak valid")
    payload = {
        "schema": 1,
        "active": active,
        "previous": str(state.get("previous", "")) if valid_version(state.get("previous")) else "",
        "last_good": str(state.get("last_good", "")) if valid_version(state.get("last_good")) else active,
        "updated_at": datetime.now().isoformat(),
    }
    path = state_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    with open(temp, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.flush(); os.fsync(handle.fileno())
    os.replace(temp, path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_program(program_dir: Path) -> dict[str, Any]:
    manifest_path = program_dir / "app-manifest.json"
    if not manifest_path.is_file():
        raise ValueError(f"Manifest program tidak ditemukan: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    for item in manifest.get("files", []):
        rel = str(item.get("path", ""))
        if not rel or rel == "app-manifest.json":
            continue
        path = program_dir / rel
        if not path.is_file():
            raise ValueError(f"File program hilang: {rel}")
        expected = str(item.get("sha256", "")).lower()
        if expected and sha256_file(path) != expected:
            raise ValueError(f"Checksum file program tidak cocok: {rel}")
    return manifest


def extract_update(package: Path, root: Path | None = None) -> tuple[Path, dict[str, Any]]:
    if not package.is_file():
        raise FileNotFoundError(package)
    temp = Path(tempfile.mkdtemp(prefix="ProdeoUpdate-"))
    with zipfile.ZipFile(package, "r") as archive:
        # Reject path traversal and unexpectedly huge archives.
        total = 0
        for item in archive.infolist():
            total += item.file_size
            resolved = (temp / item.filename).resolve()
            if temp.resolve() not in resolved.parents and resolved != temp.resolve():
                raise ValueError("Paket update berisi path tidak aman")
        if total > 600 * 1024 * 1024:
            raise ValueError("Paket update terlalu besar")
        archive.extractall(temp)
    manifest_path = temp / "update-manifest.json"
    payload = temp / "payload"
    if not manifest_path.is_file() or not payload.is_dir():
        shutil.rmtree(temp, ignore_errors=True)
        raise ValueError("Paket update Prodeo tidak lengkap")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    version = str(manifest.get("version", "")).strip()
    if not valid_version(version):
        shutil.rmtree(temp, ignore_errors=True)
        raise ValueError("Nomor versi update tidak valid")
    return temp, manifest


def install_payload(package: Path, root: Path | None = None) -> tuple[str, Path]:
    root = root or install_root()
    temp, manifest = extract_update(package, root)
    try:
        version = str(manifest["version"])
        target = root / "versions" / version
        staging = root / "versions" / f"{version}.staging"
        shutil.rmtree(staging, ignore_errors=True)
        package_type = str(manifest.get("package_type", "full") or "full").strip().lower()
        if package_type == "delta":
            # Atomic delta: clone the currently active version, overlay changed
            # files, then verify against the target version's full manifest.
            current = read_state(root).get("active", "")
            base = root / "versions" / str(current)
            if not base.is_dir():
                raise ValueError("Versi dasar untuk delta update tidak tersedia")
            shutil.copytree(base, staging)
            shutil.copytree(temp / "payload", staging, dirs_exist_ok=True)
        else:
            shutil.copytree(temp / "payload", staging)
        verify_program(staging)
        if target.is_dir():
            shutil.rmtree(target)
        os.replace(staging, target)
        # Maintenance scripts may be updated safely; the running updater keeps its code loaded.
        package_maintenance = temp / "maintenance"
        if package_maintenance.is_dir():
            maintenance = root / "maintenance"
            maintenance.mkdir(parents=True, exist_ok=True)
            for file in package_maintenance.iterdir():
                if file.is_file():
                    shutil.copy2(file, maintenance / file.name)
        recovery = root / "recovery"
        recovery.mkdir(parents=True, exist_ok=True)
        shutil.copy2(package, recovery / f"Prodeo-Update-{version}.zip")
        return version, target
    finally:
        shutil.rmtree(temp, ignore_errors=True)


def hidden_kwargs() -> dict[str, Any]:
    if os.name != "nt":
        return {}
    startup = subprocess.STARTUPINFO(); startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW; startup.wShowWindow = subprocess.SW_HIDE
    return {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0), "startupinfo": startup}


def stop_parent(pid: int | None) -> None:
    if not pid or pid <= 0 or pid == os.getpid():
        return
    try:
        os.kill(pid, 15)
    except Exception:
        pass
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.25)


def launcher(root: Path | None = None) -> Path:
    return (root or install_root()) / "ProdeoSIAPSurat.exe"


def start_app(root: Path | None = None, safe_mode: bool = False) -> subprocess.Popen:
    target = launcher(root)
    args = [str(target)] + (["--safe-mode"] if safe_mode else [])
    return subprocess.Popen(args, cwd=str(target.parent), **hidden_kwargs())


def wait_startup(version: str, timeout: int = 55) -> bool:
    marker = data_dir() / f"startup-ok-{version}.marker"
    try: marker.unlink()
    except OSError: pass
    start_app()
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if marker.is_file():
            return True
        time.sleep(0.5)
    return False



def _set_shortcut_app_id(shortcut_path: Path, app_id: str = APP_ID) -> None:
    """Set PKEY_AppUserModel_ID on an existing .lnk without pywin32/Add-Type."""
    if os.name != "nt":
        return
    import ctypes
    import uuid
    from ctypes import wintypes

    class GUID(ctypes.Structure):
        _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD), ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

        @classmethod
        def parse(cls, value: str):
            raw = uuid.UUID(value).bytes_le
            result = cls()
            result.Data1 = int.from_bytes(raw[0:4], "little")
            result.Data2 = int.from_bytes(raw[4:6], "little")
            result.Data3 = int.from_bytes(raw[6:8], "little")
            for index, byte in enumerate(raw[8:16]):
                result.Data4[index] = byte
            return result

    class PROPERTYKEY(ctypes.Structure):
        _fields_ = [("fmtid", GUID), ("pid", wintypes.DWORD)]

    class VALUE(ctypes.Union):
        _fields_ = [("pwszVal", wintypes.LPWSTR), ("punkVal", ctypes.c_void_p), ("uhVal", ctypes.c_ulonglong)]

    class PROPVARIANT(ctypes.Structure):
        _anonymous_ = ("value",)
        _fields_ = [("vt", wintypes.USHORT), ("wReserved1", wintypes.USHORT), ("wReserved2", wintypes.USHORT), ("wReserved3", wintypes.USHORT), ("value", VALUE)]

    def failed(hr: int) -> bool:
        return ctypes.c_long(hr).value < 0

    def method(obj: ctypes.c_void_p, index: int, restype, *argtypes):
        table = ctypes.cast(obj, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        return ctypes.WINFUNCTYPE(restype, ctypes.c_void_p, *argtypes)(table[index])

    ole32 = ctypes.OleDLL("ole32")
    ole32.CoInitializeEx.argtypes = [ctypes.c_void_p, wintypes.DWORD]
    ole32.CoInitializeEx.restype = ctypes.c_long
    ole32.CoCreateInstance.argtypes = [ctypes.POINTER(GUID), ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
    ole32.CoCreateInstance.restype = ctypes.c_long
    initialized = ole32.CoInitializeEx(None, 0x2)
    should_uninit = not failed(initialized)

    clsid = GUID.parse("00021401-0000-0000-C000-000000000046")
    iid_link = GUID.parse("000214F9-0000-0000-C000-000000000046")
    iid_persist = GUID.parse("0000010B-0000-0000-C000-000000000046")
    iid_store = GUID.parse("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99")
    key = PROPERTYKEY(GUID.parse("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"), 5)
    link = ctypes.c_void_p(); persist = ctypes.c_void_p(); store = ctypes.c_void_p()
    try:
        hr = ole32.CoCreateInstance(ctypes.byref(clsid), None, 1, ctypes.byref(iid_link), ctypes.byref(link))
        if failed(hr) or not link.value:
            raise OSError(f"CoCreateInstance ShellLink gagal: 0x{hr & 0xFFFFFFFF:08X}")
        query = method(link, 0, ctypes.c_long, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p))
        hr = query(link, ctypes.byref(iid_persist), ctypes.byref(persist))
        if failed(hr):
            raise OSError(f"IPersistFile tidak tersedia: 0x{hr & 0xFFFFFFFF:08X}")
        load = method(persist, 5, ctypes.c_long, wintypes.LPCWSTR, wintypes.DWORD)
        hr = load(persist, str(shortcut_path), 0)
        if failed(hr):
            raise OSError(f"Shortcut tidak dapat dibuka: 0x{hr & 0xFFFFFFFF:08X}")
        hr = query(link, ctypes.byref(iid_store), ctypes.byref(store))
        if failed(hr):
            raise OSError(f"IPropertyStore tidak tersedia: 0x{hr & 0xFFFFFFFF:08X}")
        buffer = ctypes.create_unicode_buffer(app_id)
        value = PROPVARIANT(); value.vt = 31; value.pwszVal = ctypes.cast(buffer, wintypes.LPWSTR)
        set_value = method(store, 6, ctypes.c_long, ctypes.POINTER(PROPERTYKEY), ctypes.POINTER(PROPVARIANT))
        hr = set_value(store, ctypes.byref(key), ctypes.byref(value))
        if failed(hr):
            raise OSError(f"AppUserModelID shortcut gagal: 0x{hr & 0xFFFFFFFF:08X}")
        commit = method(store, 7, ctypes.c_long)
        hr = commit(store)
        if failed(hr):
            raise OSError(f"Commit shortcut gagal: 0x{hr & 0xFFFFFFFF:08X}")
        save = method(persist, 6, ctypes.c_long, wintypes.LPCWSTR, wintypes.BOOL)
        hr = save(persist, str(shortcut_path), True)
        if failed(hr):
            raise OSError(f"Simpan shortcut gagal: 0x{hr & 0xFFFFFFFF:08X}")
    finally:
        for obj in (store, persist, link):
            if obj.value:
                try:
                    method(obj, 2, ctypes.c_ulong)(obj)
                except Exception:
                    pass
        if should_uninit:
            ole32.CoUninitialize()

def create_shortcuts(root: Path | None = None) -> None:
    root = root or install_root()
    if os.name != "nt":
        return
    desktop = Path(os.path.expandvars(r"%USERPROFILE%\Desktop"))
    start_menu = Path(os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Prodeo SIAPSurat"))
    desktop.mkdir(parents=True, exist_ok=True); start_menu.mkdir(parents=True, exist_ok=True)
    launcher_path = root / "ProdeoSIAPSurat.exe"
    repair_path = root / "ProdeoRepair.exe"
    icon = root / "app.ico"
    items = [
        (desktop / "Prodeo SIAPSurat.lnk", launcher_path, "", "Prodeo SIAPSurat"),
        (start_menu / "Prodeo SIAPSurat.lnk", launcher_path, "", "Prodeo SIAPSurat"),
        (start_menu / "Prodeo SIAPSurat - Mode Aman.lnk", launcher_path, "--safe-mode", "Prodeo SIAPSurat Mode Aman"),
        (start_menu / "Prodeo SIAPSurat - Perbaiki.lnk", repair_path, "", "Perbaiki Prodeo SIAPSurat"),
    ]
    # WScript.Shell only creates the .lnk; no code compilation occurs on user PCs.
    ps_lines = ["$w=New-Object -ComObject WScript.Shell"]
    for path, target, args, desc in items:
        esc=lambda v: str(v).replace("'", "''")
        ps_lines += [
            f"$s=$w.CreateShortcut('{esc(path)}')",
            f"$s.TargetPath='{esc(target)}'",
            f"$s.Arguments='{esc(args)}'",
            f"$s.WorkingDirectory='{esc(root)}'",
            f"$s.IconLocation='{esc(icon)},0'",
            f"$s.Description='{esc(desc)}'",
            "$s.Save()",
        ]
    subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ";".join(ps_lines)], check=True, **hidden_kwargs())
    for path, *_ in items:
        try:
            _set_shortcut_app_id(path)
        except Exception as exc:
            log(f"WARNING shortcut identity {path}: {exc}", name="shortcut.log")


def ensure_requirements(program_dir: Path, force: bool = False) -> None:
    req = program_dir / "requirements-desktop.txt"
    if not req.is_file():
        return
    marker = install_root() / "runtime" / f"requirements-{sha256_file(req)[:16]}.marker"
    if marker.is_file() and not force:
        return
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--no-warn-script-location", "-r", str(req)]
    subprocess.run(cmd, check=True, cwd=str(program_dir), **hidden_kwargs())
    marker.write_text(datetime.now().isoformat(), encoding="utf-8")


def winget_install(package_id: str) -> bool:
    exe = shutil.which("winget.exe")
    if not exe:
        return False
    result = subprocess.run([exe, "install", "--id", package_id, "--silent", "--accept-package-agreements", "--accept-source-agreements"], **hidden_kwargs())
    return result.returncode == 0


def _cli() -> int:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--create-shortcuts", action="store_true")
    args = parser.parse_args()
    if args.create_shortcuts:
        create_shortcuts()
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
