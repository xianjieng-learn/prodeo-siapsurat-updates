"""On-demand native-window launcher for Prodeo SIAPSurat."""
from __future__ import annotations

import json
import logging
import os
import socket
import sys
import threading
import time
import traceback
from pathlib import Path
from urllib.request import urlopen



def _hydrate_bootstrap_delta() -> None:
    """Complete a small 3.0.0 -> 3.0.1 bootstrap package from previous files.

    The 3.0.0 updater only understands full payloads. The public GitHub channel
    therefore uses a small compatibility payload whose manifest validates the
    files it carries. On first launch this routine copies unchanged files from
    the previous atomic version and replaces the temporary manifest with a full
    integrity manifest. Full installers and normal future delta packages do not
    enter this path.
    """
    import hashlib
    import json
    import shutil

    program = Path(os.getenv("PRODEO_PROGRAM_DIR", str(Path(__file__).resolve().parent))).resolve()
    manifest_path = program / "app-manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except Exception:
        return
    if not bool(manifest.get("bootstrap_delta")):
        return

    install_root = Path(os.getenv("PRODEO_INSTALL_ROOT", str(program.parent.parent))).resolve()
    state_path = install_root / "state.json"
    try:
        state = json.loads(state_path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise RuntimeError(f"Bootstrap update tidak dapat membaca state.json: {exc}") from exc
    previous = str(state.get("previous", "") or "").strip()
    source = install_root / "versions" / previous
    if not previous or not source.is_dir():
        raise RuntimeError("Versi sebelumnya tidak tersedia untuk menyelesaikan bootstrap update")

    for src in source.rglob("*"):
        if not src.is_file() or "__pycache__" in src.parts or src.suffix in {".pyc", ".pyo"}:
            continue
        rel = src.relative_to(source)
        if rel.as_posix() == "app-manifest.json":
            continue
        dst = program / rel
        if dst.exists():
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    rows = []
    for item in sorted(program.rglob("*")):
        if not item.is_file() or "__pycache__" in item.parts or item.suffix in {".pyc", ".pyo"}:
            continue
        rel = item.relative_to(program).as_posix()
        if rel == "app-manifest.json":
            continue
        digest = hashlib.sha256()
        with item.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        rows.append({"path": rel, "sha256": digest.hexdigest(), "size": item.stat().st_size})
    full_manifest = {
        "name": "Prodeo SIAPSurat Desktop",
        "version": "3.0.1",
        "schema": 2,
        "generated_at": "bootstrap-hydrated",
        "files": rows,
    }
    temp = manifest_path.with_suffix(".tmp")
    temp.write_text(json.dumps(full_manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temp, manifest_path)


_hydrate_bootstrap_delta()

from app_meta import APP_NAME, APP_USER_MODEL_ID, APP_VERSION
from app_paths import DATA_DIR, INSTALL_ROOT, LOG_DIR, PROGRAM_DIR, WEBVIEW_DATA_DIR, ensure_data_dirs
from logging_setup import configure_logging
from native_notifications import DesktopNotificationApi
from windows_taskbar import apply_taskbar_identity

ensure_data_dirs()
os.chdir(PROGRAM_DIR)
sys.path.insert(0, str(PROGRAM_DIR))
os.environ["PRODEO_DESKTOP_ON_DEMAND"] = "1"
os.environ.setdefault("PYTHONUTF8", "1")
SAFE_MODE = os.getenv("PRODEO_SAFE_MODE", "").strip().lower() in {"1", "true", "yes", "on"}
configure_logging(LOG_DIR)
log = logging.getLogger("desktop")


def _set_windows_app_identity() -> None:
    if os.name != "nt":
        return
    try:
        import ctypes
        result = ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
        if result != 0:
            log.warning("SetCurrentProcessExplicitAppUserModelID returned %s", result)
    except Exception:
        log.exception("Could not set Windows AppUserModelID")


def _watch_and_apply_windows_icon(icon_path: Path, timeout: float = 20.0) -> None:
    if os.name != "nt" or not icon_path.exists():
        return
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        current_pid = os.getpid()
        IMAGE_ICON, LR_LOADFROMFILE, WM_SETICON = 1, 0x0010, 0x0080
        ICON_SMALL, ICON_BIG = 0, 1
        user32.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
        user32.LoadImageW.restype = wintypes.HANDLE
        icon_big = user32.LoadImageW(None, str(icon_path), IMAGE_ICON, 32, 32, LR_LOADFROMFILE)
        icon_small = user32.LoadImageW(None, str(icon_path), IMAGE_ICON, 16, 16, LR_LOADFROMFILE)
        enum_proc_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def apply() -> bool:
            found = False
            @enum_proc_type
            def enum_proc(hwnd, _):
                nonlocal found
                pid = wintypes.DWORD()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                if pid.value != current_pid:
                    return True
                length = user32.GetWindowTextLengthW(hwnd)
                buf = ctypes.create_unicode_buffer(length + 1)
                user32.GetWindowTextW(hwnd, buf, length + 1)
                if APP_NAME not in buf.value:
                    return True
                if icon_big:
                    user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, int(icon_big))
                if icon_small:
                    user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, int(icon_small))
                try:
                    apply_taskbar_identity(
                        int(hwnd),
                        app_id=APP_USER_MODEL_ID,
                        launcher_path=INSTALL_ROOT / "ProdeoSIAPSurat.exe",
                        icon_path=icon_path,
                        display_name=APP_NAME,
                    )
                except Exception:
                    log.exception("Could not apply per-window taskbar identity")
                found = True
                return False
            user32.EnumWindows(enum_proc, 0)
            return found

        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if apply():
                log.info("Custom taskbar icon applied")
                return
            time.sleep(0.2)
    except Exception:
        log.exception("Could not apply taskbar icon")


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _wait_ready(url: str, timeout: float = 30.0) -> None:
    deadline = time.monotonic() + timeout
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        try:
            with urlopen(url, timeout=1.5) as response:
                if response.status == 200:
                    return
        except Exception as exc:
            last_error = exc
        time.sleep(0.2)
    raise RuntimeError(f"Backend tidak siap: {last_error}")


def _acquire_single_instance():
    if os.name != "nt":
        return True
    import ctypes
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.CreateMutexW(None, False, "Local\\ProdeoSIAPSuratDesktopV2")
    if not handle:
        return None
    if kernel32.GetLastError() == 183:
        kernel32.CloseHandle(handle)
        return None
    return handle


def _activate_existing_window() -> None:
    if os.name != "nt":
        return
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        found = 0
        enum_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        @enum_type
        def enum_proc(hwnd, _):
            nonlocal found
            if not user32.IsWindowVisible(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            if APP_NAME.lower() in buf.value.lower():
                found = int(hwnd); return False
            return True
        user32.EnumWindows(enum_proc, 0)
        if found:
            user32.ShowWindow(found, 9)
            user32.SetForegroundWindow(found)
    except Exception:
        log.debug("Could not activate existing window", exc_info=True)


def _release_single_instance(handle) -> None:
    if os.name == "nt" and handle not in (None, True):
        try:
            import ctypes
            ctypes.windll.kernel32.CloseHandle(handle)
        except Exception:
            pass


def _startup_marker() -> Path:
    return DATA_DIR / f"startup-ok-{APP_VERSION}.marker"

def _crash_state_file() -> Path:
    return DATA_DIR / "startup-state.json"

def _begin_startup() -> bool:
    """Record startup and return True when automatic safe mode is advisable."""
    path = _crash_state_file()
    state = {"failures": 0, "last_ok": True}
    try:
        state.update(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        pass
    auto_safe = not SAFE_MODE and not bool(state.get("last_ok", True)) and int(state.get("failures", 0)) >= 2
    state["last_ok"] = False; state["failures"] = int(state.get("failures", 0)) + 1; state["version"] = APP_VERSION
    path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    return auto_safe

def _mark_startup_ok() -> None:
    _crash_state_file().write_text(json.dumps({"failures": 0, "last_ok": True, "version": APP_VERSION}, indent=2), encoding="utf-8")


def main() -> int:
    global SAFE_MODE
    _set_windows_app_identity()
    auto_safe = _begin_startup()
    if auto_safe:
        SAFE_MODE = True
        os.environ["PRODEO_SAFE_MODE"] = "1"
        log.warning("Mode Aman otomatis diaktifkan setelah kegagalan startup berulang")
    instance_handle = _acquire_single_instance()
    if instance_handle is None:
        _activate_existing_window()
        return 0

    server = None
    thread = None
    try:
        import uvicorn
        import webview
        from webapp import app

        port = _free_port()
        base_url = f"http://127.0.0.1:{port}"
        config = uvicorn.Config(
            app,
            host="127.0.0.1",
            port=port,
            log_level="warning",
            access_log=False,
            server_header=False,
            log_config=None,
        )
        server = uvicorn.Server(config)
        server.install_signal_handlers = lambda: None
        thread = threading.Thread(target=server.run, name="prodeo-backend", daemon=True)
        thread.start()
        _wait_ready(f"{base_url}/api/ready")
        _startup_marker().write_text(time.strftime("%Y-%m-%dT%H:%M:%S"), encoding="utf-8")
        _mark_startup_ok()

        icon_path = PROGRAM_DIR / "public" / "favicon.ico"
        desktop_api = DesktopNotificationApi(icon_path)
        window_title = APP_NAME + (" — Mode Aman" if SAFE_MODE else "")
        webview.create_window(
            window_title,
            base_url,
            width=1360,
            height=820,
            min_size=(1024, 650),
            resizable=True,
            confirm_close=False,
            background_color="#F5F6F8",
            js_api=desktop_api,
        )
        threading.Thread(target=_watch_and_apply_windows_icon, args=(icon_path,), daemon=True).start()
        log.info("Desktop window opened: version=%s port=%s safe_mode=%s", APP_VERSION, port, SAFE_MODE)
        webview.start(
            gui="edgechromium",
            debug=False,
            private_mode=False,
            storage_path=str(WEBVIEW_DATA_DIR),
            icon=str(icon_path) if icon_path.exists() else None,
        )
        return 0
    except Exception as exc:
        log.exception("Desktop app failed")
        message = f"{APP_NAME} gagal dibuka.\n\n{exc}\n\nLog: {LOG_DIR / 'desktop.log'}"
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, message, APP_NAME, 0x10)
        except Exception:
            if sys.stderr is not None:
                print(message, file=sys.stderr)
                traceback.print_exc()
        return 1
    finally:
        if server is not None:
            server.should_exit = True
        if thread is not None and thread.is_alive():
            thread.join(timeout=8)
        _release_single_instance(instance_handle)
        log.info("Desktop backend stopped")


if __name__ == "__main__":
    raise SystemExit(main())
