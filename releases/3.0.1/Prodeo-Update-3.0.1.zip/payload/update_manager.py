"""Online/offline update discovery and native maintenance handoff."""
from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import subprocess
import threading
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from app_meta import APP_VERSION, DEFAULT_UPDATE_MANIFEST_URL
from app_paths import INSTALL_ROOT, UPDATE_DIR

log = logging.getLogger("updater")


def _version_tuple(value: str) -> tuple[int, ...]:
    parts = []
    for part in str(value).strip().split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        parts.append(int(digits or 0))
    return tuple(parts)


def check_online(manifest_url: str = "") -> dict[str, Any]:
    url = (manifest_url or DEFAULT_UPDATE_MANIFEST_URL).strip()
    if not url:
        return {"ok": True, "configured": False, "update_available": False, "message": "URL pembaruan online belum dikonfigurasi"}
    request = urllib.request.Request(url, headers={"User-Agent": f"ProdeoSIAPSurat/{APP_VERSION}"})
    with urllib.request.urlopen(request, timeout=15) as response:
        raw = response.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024:
            raise ValueError("Manifest pembaruan terlalu besar")
        manifest = json.loads(raw.decode("utf-8-sig"))
    if not isinstance(manifest, dict):
        raise ValueError("Format manifest pembaruan tidak valid")
    latest = str(manifest.get("version", "0.0.0")).strip()
    if not latest or not any(ch.isdigit() for ch in latest):
        raise ValueError("Versi pada manifest pembaruan tidak valid")
    download_url = str(manifest.get("download_url") or manifest.get("download") or "").strip()
    if download_url:
        manifest["download_url"] = urllib.parse.urljoin(url, download_url)
    return {
        "ok": True, "configured": True, "current_version": APP_VERSION,
        "latest_version": latest, "update_available": _version_tuple(latest) > _version_tuple(APP_VERSION),
        "manifest": manifest,
    }


def download_online(manifest: dict[str, Any]) -> Path:
    url = str(manifest.get("download_url") or manifest.get("download") or "").strip()
    if not url:
        raise ValueError("Manifest tidak memiliki download_url")
    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    target = UPDATE_DIR / f"Prodeo-Update-{manifest.get('version', 'unknown')}.zip"
    request = urllib.request.Request(url, headers={"User-Agent": f"ProdeoSIAPSurat/{APP_VERSION}"})
    with urllib.request.urlopen(request, timeout=120) as response, open(target, "wb") as handle:
        shutil.copyfileobj(response, handle)
    expected = str(manifest.get("sha256", "")).lower().strip()
    if expected:
        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        if digest != expected:
            target.unlink(missing_ok=True)
            raise ValueError("Checksum paket pembaruan tidak cocok")
    return target


def stage_offline(uploaded_path: Path) -> dict[str, Any]:
    import zipfile
    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(uploaded_path, "r") as archive:
        try:
            manifest = json.loads(archive.read("update-manifest.json").decode("utf-8-sig"))
        except KeyError as exc:
            raise ValueError("Paket bukan update Prodeo yang valid") from exc
        if not any(name.startswith("payload/") for name in archive.namelist()):
            raise ValueError("Folder payload tidak ditemukan dalam paket update")
    version = str(manifest.get("version", "")).strip()
    if not version:
        raise ValueError("Versi update tidak ditemukan")
    target = UPDATE_DIR / f"Prodeo-Update-{version}.zip"
    shutil.copy2(uploaded_path, target)
    return {"ok": True, "version": version, "package": str(target), "manifest": manifest}


def _hidden_kwargs() -> dict:
    if os.name != "nt": return {}
    startup = subprocess.STARTUPINFO(); startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW; startup.wShowWindow = subprocess.SW_HIDE
    return {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0), "startupinfo": startup}


def launch_maintenance(mode: str, package: str = "") -> dict[str, Any]:
    if mode == "repair":
        executable = INSTALL_ROOT / "ProdeoRepair.exe"
        args = [str(executable), "--parent-pid", str(os.getpid())]
    else:
        executable = INSTALL_ROOT / "ProdeoUpdater.exe"
        args = [str(executable), "--mode", mode, "--parent-pid", str(os.getpid())]
        if package:
            args += ["--package", str(package)]
    if not executable.is_file():
        raise FileNotFoundError(f"Program pemeliharaan tidak ditemukan: {executable}")

    def _start() -> None:
        try:
            subprocess.Popen(args, cwd=str(INSTALL_ROOT), **_hidden_kwargs())
        except Exception:
            log.exception("Gagal memulai proses maintenance")

    timer = threading.Timer(1.0, _start); timer.daemon = True; timer.start()
    return {"ok": True, "maintenance_started": True, "mode": mode}
