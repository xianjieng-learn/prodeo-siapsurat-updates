"""Application metadata shared by launcher, UI, updater, and diagnostics."""
from __future__ import annotations

APP_NAME = "Prodeo SIAPSurat"
APP_VERSION = "3.0.1"
LAUNCHER_VERSION = "3.0.1"
RELEASE_DATE = "31 Juli 2026"
APP_USER_MODEL_ID = "PAJaktim.ProdeoSIAPSurat.Desktop"
UPDATE_CHANNEL = "stable"
DEFAULT_UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/xianjieng-learn/prodeo-siapsurat-updates/main/channel/stable.json"
STATE_SCHEMA = 1
