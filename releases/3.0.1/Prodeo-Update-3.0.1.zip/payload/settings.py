"""
settings.py — Manage runtime settings (persisted to settings.json).
"""

import os
import json
import logging
from copy import deepcopy
from typing import Optional
from datetime import datetime

from app_meta import DEFAULT_UPDATE_MANIFEST_URL

logger = logging.getLogger("settings")

DEFAULT_DOC_TARGETS = [
    "Surat Pertimbangan Panitera",
    "Surat Penetapan Ketua",
    "Surat Keputusan KPA",
]

DEFAULT_DOC_SIGNERS = {
    "Surat Pertimbangan Panitera": "panitera",
    "Surat Penetapan Ketua": "wakil_ketua",
    "Surat Keputusan KPA": "sekretaris_kpa",
}

DEFAULT_STAMP_POSITIONS = {
    "Surat Pertimbangan Panitera": {"pos_x": 0.542, "pos_y": 0.775},
    "Surat Penetapan Ketua": {"pos_x": 0.543, "pos_y": 0.848},
    "Surat Keputusan KPA": {"pos_x": 0.537, "pos_y": 0.732},
}

# Legacy constant name dipertahankan untuk backward compatibility antar modul.
DOC_SIGNER_OPTIONS = {
    "panitera": {
        "label": "Panitera",
        "penandatangan_value": "12",
        "stamp_file": "assets/stempel_panitera.png",
        "is_builtin": True,
    },
    "wakil_ketua": {
        "label": "Wakil Ketua",
        "penandatangan_value": "4",
        "stamp_file": "assets/stempel_wakil_ketua.png",
        "is_builtin": True,
    },
    "sekretaris_kpa": {
        "label": "Sekretaris KPA",
        "penandatangan_value": "6",
        "stamp_file": "assets/stempel_sekretaris_kpa.png",
        "is_builtin": True,
    },
}

DEFAULT_SIGNERS = deepcopy(DOC_SIGNER_OPTIONS)

DEFAULT_MANUAL_SIGNERS = {
    "Surat Pertimbangan Panitera": {"signer_key": "panitera", "name": ""},
    "Surat Penetapan Ketua": {"signer_key": "wakil_ketua", "name": ""},
    "Surat Keputusan KPA": {"signer_key": "sekretaris_kpa", "name": ""},
}

DEFAULT_SETTINGS = {
    "doc_targets": DEFAULT_DOC_TARGETS,
    "doc_signers": DEFAULT_DOC_SIGNERS,
    "signers": DEFAULT_SIGNERS,
    "stamp_positions": DEFAULT_STAMP_POSITIONS,
    "manual_signers": DEFAULT_MANUAL_SIGNERS,
    "siapsurat_username": "",
    "siapsurat_base_url": "https://siapsurat.pa-jakartatimur.go.id",
    "aps_badilag_username": "",
    "monitoring_bulan": datetime.now().month,
    "monitoring_tahun": datetime.now().year,
    "headless_mode": True,
    "debug_mode": False,
    "libreoffice_path": "soffice",
    "monitoring_url": "http://25.24.23.7/pendukung2020/monitoring_perkara_prodeo",
    "abt_url": "http://25.24.23.7/aps_badilag",
    "abt_output_path": "",
    "update_manifest_url": DEFAULT_UPDATE_MANIFEST_URL,
    "backup_max_versions": 10,
    "backup_temp_days": 60,
    "job_timeout_minutes": 20,
    "playwright_legacy_enabled": False,
}

from app_paths import SETTINGS_FILE
from credential_store import APS_TARGET, SIAPSURAT_TARGET, CredentialStoreError
import credential_store


class Settings:
    """Runtime settings persisted separately from replaceable program files."""

    def __init__(self):
        self._data = deepcopy(DEFAULT_SETTINGS)
        self._legacy_passwords: dict[str, str] = {}
        self._load()
        self._migrate_plaintext_credentials()

    def _load(self):
        if SETTINGS_FILE.is_file():
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                # Capture passwords only for one-time migration; never keep them
                # in the settings payload after a successful Credential Manager write.
                self._legacy_passwords = {
                    "siapsurat": str(loaded.pop("siapsurat_password", "") or ""),
                    "aps": str(loaded.pop("aps_badilag_password", "") or ""),
                }
                self._data.update(loaded)
                # v3.0.1: instalasi lama yang masih menyimpan string kosong
                # otomatis memakai kanal update GitHub resmi.
                if not str(self._data.get("update_manifest_url", "") or "").strip():
                    self._data["update_manifest_url"] = DEFAULT_UPDATE_MANIFEST_URL
                logger.info("Settings loaded from %s", SETTINGS_FILE)
            except Exception as e:
                logger.warning("Gagal load settings: %s", e)

    def _migrate_plaintext_credentials(self):
        if not credential_store.available():
            return
        migrated = False
        pairs = (
            ("siapsurat", SIAPSURAT_TARGET, "siapsurat_username"),
            ("aps", APS_TARGET, "aps_badilag_username"),
        )
        for key, target, user_key in pairs:
            password = self._legacy_passwords.get(key, "")
            if not password:
                continue
            try:
                current = credential_store.read(target)
                if current is None:
                    credential_store.write(target, str(self._data.get(user_key, "")), password)
                migrated = True
            except Exception as exc:
                logger.warning("Migrasi kredensial %s gagal: %s", key, exc)
        if migrated:
            self.save()

    def save(self):
        SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
        temp = SETTINGS_FILE.with_suffix(".tmp")
        payload = deepcopy(self._data)
        payload.pop("siapsurat_password", None)
        payload.pop("aps_badilag_password", None)
        with open(temp, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        temp.replace(SETTINGS_FILE)
        logger.info("Settings saved to %s", SETTINGS_FILE)

    def _credential(self, kind: str):
        target = SIAPSURAT_TARGET if kind == "siapsurat" else APS_TARGET
        try:
            return credential_store.read(target)
        except Exception as exc:
            logger.warning("Gagal membaca Credential Manager (%s): %s", kind, exc)
            return None

    def set_credential(self, kind: str, username: str, password: str | None = None):
        if kind not in {"siapsurat", "aps"}:
            raise ValueError("Jenis kredensial tidak dikenal")
        user_key = "siapsurat_username" if kind == "siapsurat" else "aps_badilag_username"
        target = SIAPSURAT_TARGET if kind == "siapsurat" else APS_TARGET
        username = str(username or "").strip()
        self._data[user_key] = username
        existing = self._credential(kind)
        if password is None or password == "":
            if existing and existing.username != username:
                credential_store.write(target, username, existing.password)
        else:
            credential_store.write(target, username, str(password))
        self.save()

    def delete_credential(self, kind: str) -> bool:
        target = SIAPSURAT_TARGET if kind == "siapsurat" else APS_TARGET
        deleted = credential_store.delete(target)
        user_key = "siapsurat_username" if kind == "siapsurat" else "aps_badilag_username"
        self._data[user_key] = ""
        self.save()
        return deleted

    def credential_status(self) -> dict:
        siap = self._credential("siapsurat")
        aps = self._credential("aps")
        return {
            "siapsurat": {"stored": bool(siap and siap.password), "username": (siap.username if siap else self._data.get("siapsurat_username", ""))},
            "aps": {"stored": bool(aps and aps.password), "username": (aps.username if aps else self._data.get("aps_badilag_username", ""))},
            "backend": "windows_credential_manager" if credential_store.available() else "legacy_or_environment",
        }

    def get(self, key: str, default=None):
        if key == "siapsurat_password":
            cred = self._credential("siapsurat")
            return cred.password if cred else self._legacy_passwords.get("siapsurat", default or "")
        if key == "aps_badilag_password":
            cred = self._credential("aps")
            return cred.password if cred else self._legacy_passwords.get("aps", default or "")
        if key == "siapsurat_username":
            cred = self._credential("siapsurat")
            return cred.username if cred and cred.username else self._data.get(key, default)
        if key == "aps_badilag_username":
            cred = self._credential("aps")
            return cred.username if cred and cred.username else self._data.get(key, default)
        return self._data.get(key, default)

    def set(self, key: str, value):
        if key in {"siapsurat_password", "aps_badilag_password"}:
            kind = "siapsurat" if key == "siapsurat_password" else "aps"
            user_key = "siapsurat_username" if kind == "siapsurat" else "aps_badilag_username"
            self.set_credential(kind, self._data.get(user_key, ""), str(value))
            return
        self._data[key] = value

    def update(self, data: dict):
        clean = dict(data)
        clean.pop("siapsurat_password", None)
        clean.pop("aps_badilag_password", None)
        self._data.update(clean)

    def all(self) -> dict:
        payload = deepcopy(self._data)
        status = self.credential_status()
        payload["siapsurat_username"] = status["siapsurat"]["username"]
        payload["aps_badilag_username"] = status["aps"]["username"]
        payload["siapsurat_password"] = ""
        payload["aps_badilag_password"] = ""
        payload["siapsurat_password_stored"] = status["siapsurat"]["stored"]
        payload["aps_badilag_password_stored"] = status["aps"]["stored"]
        payload["credential_backend"] = status["backend"]
        return payload

    def doc_targets(self) -> list[str]:
        return self._data.get("doc_targets", DEFAULT_DOC_TARGETS)

    def signers(self) -> dict[str, dict]:
        """Signer registry dinamis (builtin + custom) dengan fallback aman."""
        configured = self._data.get("signers", {}) or {}
        merged = deepcopy(DEFAULT_SIGNERS)

        if isinstance(configured, dict):
            for key, value in configured.items():
                if not isinstance(key, str) or not isinstance(value, dict):
                    continue
                base = merged.get(key, {"is_builtin": False})
                merged[key] = {
                    **base,
                    "label": str(value.get("label", base.get("label", key))).strip() or key,
                    "penandatangan_value": str(value.get("penandatangan_value", base.get("penandatangan_value", ""))).strip(),
                    "stamp_file": str(value.get("stamp_file", base.get("stamp_file", ""))).strip(),
                    "is_builtin": bool(base.get("is_builtin", value.get("is_builtin", False))),
                }

        return merged

    def doc_signers(self) -> dict[str, str]:
        configured = self._data.get("doc_signers", {}) or {}
        merged = dict(DEFAULT_DOC_SIGNERS)
        signers = self.signers()

        for k, v in configured.items() if isinstance(configured, dict) else []:
            if isinstance(k, str) and isinstance(v, str) and v in signers:
                merged[k] = v
        return merged

    def signer_for_doc(self, doc_type: str) -> dict:
        signers = self.signers()
        signer_key = self.doc_signers().get(doc_type, "")
        signer = signers.get(signer_key)
        if signer:
            return {"key": signer_key, **signer}

        # fallback terakhir: default bawaan doc
        fallback_key = DEFAULT_DOC_SIGNERS.get(doc_type, "")
        fallback = signers.get(fallback_key, {})
        return {"key": fallback_key, **fallback}

    def signer_for_doc_by_key(self, signer_key: str) -> dict:
        """Resolve signer directly by key (for per-perkara manual TTD)."""
        signers = self.signers()
        signer = signers.get(signer_key, {})
        return {"key": signer_key, "label": signer.get("label", signer_key), "name": signer.get("name", ""), **signer}

    def tujuan_for_doc(self, doc_type: str) -> str:
        """Resolve tujuan surat from signer label."""
        signer = self.signer_for_doc(doc_type)
        return signer.get("label", "")

    def manual_signer_for_doc(self, doc_type: str) -> dict:
        """Resolve manual signer for a doc type: signer_key, label (title), name."""
        ms = self.manual_signers().get(doc_type, {})
        signer_key = ms.get("signer_key", "")
        signers = self.signers()
        signer = signers.get(signer_key, {})
        return {
            "signer_key": signer_key,
            "label": signer.get("label", signer_key),
            "name": ms.get("name", ""),
        }

    def manual_signers(self) -> dict[str, dict]:
        """Manual TTD config per doc type: signer_key + name override."""
        configured = self._data.get("manual_signers", {}) or {}
        merged = deepcopy(DEFAULT_MANUAL_SIGNERS)
        if isinstance(configured, dict):
            for doc, val in configured.items():
                if not isinstance(doc, str) or not isinstance(val, dict):
                    continue
                if doc not in merged:
                    continue
                merged[doc] = {
                    "signer_key": str(val.get("signer_key", merged[doc].get("signer_key", ""))).strip(),
                    "name": str(val.get("name", merged[doc].get("name", ""))).strip(),
                }
        return merged

    def stamp_positions(self) -> dict[str, dict]:
        configured = self._data.get("stamp_positions", {}) or {}
        merged = deepcopy(DEFAULT_STAMP_POSITIONS)
        if isinstance(configured, dict):
            for doc, value in configured.items():
                if not isinstance(doc, str) or not isinstance(value, dict):
                    continue
                if doc not in merged:
                    continue
                try:
                    px = float(value.get("pos_x", merged[doc]["pos_x"]))
                    py = float(value.get("pos_y", merged[doc]["pos_y"]))
                except Exception:
                    continue
                merged[doc] = {
                    "pos_x": max(0.0, min(1.0, px)),
                    "pos_y": max(0.0, min(1.0, py)),
                }
        return merged


runtime_settings = Settings()
