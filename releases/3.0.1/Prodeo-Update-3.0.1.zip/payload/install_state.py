"""Atomic version state shared by launcher, updater, repair and diagnostics."""
from __future__ import annotations

import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from app_paths import INSTALL_ROOT

STATE_FILE = INSTALL_ROOT / "state.json"
_VERSION_RE = re.compile(r"^[0-9]+(?:\.[0-9]+){1,3}(?:[-A-Za-z0-9.]+)?$")


def valid_version(value: object) -> bool:
    return bool(_VERSION_RE.fullmatch(str(value or "").strip()))


def default_state(active: str = "3.0.1") -> dict[str, Any]:
    return {
        "schema": 1,
        "active": active,
        "previous": "",
        "last_good": active,
        "updated_at": datetime.now().isoformat(),
    }


def read_state(path: Path = STATE_FILE) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(data, dict) or not valid_version(data.get("active")):
            raise ValueError("state.json tidak memiliki versi aktif yang valid")
        state = default_state(str(data["active"]))
        state.update(data)
        for key in ("previous", "last_good"):
            if state.get(key) and not valid_version(state[key]):
                state[key] = ""
        return state
    except FileNotFoundError:
        return default_state()


def write_state(state: dict[str, Any], path: Path = STATE_FILE) -> None:
    active = str(state.get("active", "")).strip()
    if not valid_version(active):
        raise ValueError("Versi aktif tidak valid")
    payload = default_state(active)
    payload.update(state)
    payload["updated_at"] = datetime.now().isoformat()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp, path)
